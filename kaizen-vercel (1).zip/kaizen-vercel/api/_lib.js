const crypto = require('crypto');
const URL_ = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOK = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const KEY = 'kaizen:state';

async function cmd(args) {
  const r = await fetch(URL_, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + TOK, 'Content-Type': 'application/json' },
    body: JSON.stringify(args),
  });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error || 'redis error');
  return j.result;
}
async function load() {
  const v = await cmd(['GET', KEY]);
  let s = null;
  try { s = v ? JSON.parse(v) : null; } catch (e) {}
  return s && Array.isArray(s.q) ? s : { q: [], dc: '', u: 0 };
}
async function save(s) {
  s.u = Date.now();
  await cmd(['SET', KEY, JSON.stringify(s)]);
  return s;
}
const secret = () => process.env.SESSION_SECRET || process.env.ADMIN_PASSWORD || '';
const sign = (exp) => crypto.createHmac('sha256', secret()).update(String(exp)).digest('hex');
function makeToken() { const exp = Date.now() + 7 * 864e5; return exp + '.' + sign(exp); }
function verify(t) {
  if (!t || !secret()) return false;
  const [e, sig] = String(t).split('.');
  if (!e || !sig || +e < Date.now()) return false;
  const a = Buffer.from(sig), b = Buffer.from(sign(e));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function same(a, b) {
  const h = (x) => crypto.createHash('sha256').update(String(x)).digest();
  return crypto.timingSafeEqual(h(a), h(b));
}
module.exports = { load, save, makeToken, verify, same };
