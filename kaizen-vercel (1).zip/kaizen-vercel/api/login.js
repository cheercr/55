const { makeToken, same } = require('./_lib');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).end();
  const real = process.env.ADMIN_PASSWORD;
  if (!real) return res.status(500).json({ error: 'ยังไม่ได้ตั้งค่า ADMIN_PASSWORD' });
  const pw = (req.body && req.body.password) || '';
  if (!same(pw, real)) {
    await new Promise((r) => setTimeout(r, 1000)); // หน่วงเวลาลดการเดารหัส
    return res.status(401).json({ error: 'รหัสผ่านไม่ถูกต้อง' });
  }
  res.json({ token: makeToken() });
};
