const { load, save, verify } = require('./_lib');
const KINDS = ['แชท/ส่วนตัว', 'สตรีมเมอร์', 'ร้านค้า', 'แก๊ง/กิลด์/แฟมิลี่', 'ชุมชน/ประเทศ', 'อื่นๆ'];
const cl = (v, n) => String(v || '').trim().slice(0, n);

module.exports = async (req, res) => {
  try {
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=3, stale-while-revalidate=5');
      return res.json(await load());
    }
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).end();
    const auth = (req.headers.authorization || '').replace(/^Bearer /, '');
    if (!verify(auth)) return res.status(401).json({ error: 'unauthorized' });

    const b = req.body || {};
    const s = await load();
    switch (b.action) {
      case 'add': {
        const n = cl(b.n, 40);
        if (!n) return res.status(400).json({ error: 'ใส่ชื่อลูกค้าก่อน' });
        if (s.q.length >= 300) return res.status(400).json({ error: 'คิวเต็ม ลองล้างคิวที่เสร็จแล้วก่อน' });
        s.q.push({
          id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
          n, k: KINDS.includes(b.k) ? b.k : 'อื่นๆ',
          p: ['n', 'x2', 'x3'].includes(b.p) ? b.p : 'n',
          note: cl(b.note, 60), s: 'wait', t: Date.now(),
        });
        break;
      }
      case 'status': {
        const o = s.q.find((x) => x.id === b.id);
        if (o && ['wait', 'doing', 'done'].includes(b.s)) o.s = b.s;
        break;
      }
      case 'del': s.q = s.q.filter((x) => x.id !== b.id); break;
      case 'clear': s.q = s.q.filter((x) => x.s !== 'done'); break;
      case 'link': {
        const v = cl(b.dc, 200);
        if (v && !/^https:\/\//.test(v)) return res.status(400).json({ error: 'ลิงก์ต้องขึ้นต้นด้วย https://' });
        s.dc = v; break;
      }
      default: return res.status(400).json({ error: 'bad action' });
    }
    res.json(await save(s));
  } catch (e) {
    res.status(500).json({ error: 'server error' });
  }
};
